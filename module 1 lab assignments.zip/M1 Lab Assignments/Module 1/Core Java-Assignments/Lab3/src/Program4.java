import java.util.Scanner;

public class Program4 {
	void method(char a[]) {
		int i, j, c;
		for (i = 0; i < a.length; i++) {
			if (a[i] == '9')
				continue;
				for (j = i + 1, c = 1; j < a.length; j++)
					if (a[i] == a[j]) {
						a[j] = '9';
						c++;
					}
				System.out.println(a[i] + ":" + c + "times");
			}
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program4 p = new Program4();
		Scanner s = new Scanner(System.in);
		System.out.println("enter string ");
		String s1 = s.next();
		char[] c = new char[s1.length()];
		for (int k = 0; k < s1.length(); k++)
			c[k] = s1.charAt(k);
		p.method(c);
		s.close();
	}

}
