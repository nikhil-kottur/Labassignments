import java.util.Scanner;

public class Program1 {
	int calculateSum(int n) {
		int i, sum = 0, count = 0;
		for (i = 1; count < n; i++)
			if (i % 3 == 0 || i % 5 == 0) {
				sum = sum + i;
				count++;
			}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program1 p = new Program1();
		System.out.println("Enter n");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		System.out.println(p.calculateSum(n));
		s.close();
	}

}
