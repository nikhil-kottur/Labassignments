import java.util.Scanner;

public class Program4 {
	boolean checkNumber(int n) {
		int i;
		boolean b = false;
		for (i = 1; i <= n; i = i * 2)
			if (i == n)
				b = true;
		return b;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program4 p = new Program4();
		Scanner s = new Scanner(System.in);
		System.out.println("enter n");
		int n = s.nextInt();
		System.out.println(p.checkNumber(n));
		s.close();
	}

}
