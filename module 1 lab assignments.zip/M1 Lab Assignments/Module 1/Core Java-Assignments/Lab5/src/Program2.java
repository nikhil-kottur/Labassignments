import java.util.Scanner;

class Program2 
{ 
    static int fibonacci(int n) 
    { 
    if (n <= 1) 
       return n; 
    return fibonacci(n-1) + fibonacci(n-2); 
    } 
       
    public static void main (String args[]) 
    { //Program2 p=new Program2();
    Scanner s=new Scanner(System.in);
    int n=s.nextInt();
    System.out.println("The "+n+"th value in fibonacci series is "+(fibonacci(n))); 
    s.close();
    } 
} 